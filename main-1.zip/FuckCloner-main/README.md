# FuckCloner

Saya tidak bertanggung jawab atas
Apa yang anda lakukan, semata-mata tools ini
Hanya untuk menambah wawasan saja
Saya tidak menyuruh anda untuk melakukan
Tindakan yang berhubungan merugikan orang lain

 git clone https://github.com/MRZOK3R/FuckCloner

 cd FuckCloner

 python3 fuck.py

# Happy Fun 🤘
# JANGAN DI PERJUAL BELIKAN ALAT INI
# MR.ZOK3R, A-KENZI, PANJI HITAM
